package com.airbnb.lottie.animation.content;

public interface ModifierContent {
}
