package com.airbnb.lottie.samples.model

data class AnimationResponseV2(
    val data: List<AnimationDataV2> = emptyList(),
)