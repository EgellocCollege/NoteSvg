package android_svg_code_render;

public class AndroidVersionSimulation {

    //This static field is set from Main after the minimum Android API version was set
    public static int SDK_INT;
}
