package android.content.res;

import java.io.InputStream;

/**
 * Created by racs on 2015.03.17..
 */
public class Resources {
    public InputStream openRawResource(int resourceId) {
        throw new RuntimeException("Resources.openRawResources() method is not implemented.");
    }
}
