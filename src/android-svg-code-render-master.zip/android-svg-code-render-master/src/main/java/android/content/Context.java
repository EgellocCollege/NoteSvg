package android.content;

/**
 * Created by racs on 2015.03.17..
 */
public class Context {
    public Context getResources() {
        return this;
    }
}
