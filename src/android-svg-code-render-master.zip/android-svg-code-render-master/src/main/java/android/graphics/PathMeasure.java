package android.graphics;

/**
 * Created by racs on 2015.03.17..
 */
public class PathMeasure {
    public PathMeasure(Path path, boolean b) {
        //TODO: Path measure is not supported yet
    }

    public float getLength() {
        throw new RuntimeException("PathMeasure.getLength() method is not supported.");
    }
}
