package android.graphics;

import android_svg_code_render.AndroidClass;

public class PorterDuff extends AndroidClass {

    public enum Mode {
        DST_IN
    }
}