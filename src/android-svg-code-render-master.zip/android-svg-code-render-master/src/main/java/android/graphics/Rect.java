package android.graphics;

/**
 * Created by racs on 2015.03.17..
 */
public class Rect {

    public Rect() {
        //TODO: find out if creating Rect instance in the output make sense
    }
}
