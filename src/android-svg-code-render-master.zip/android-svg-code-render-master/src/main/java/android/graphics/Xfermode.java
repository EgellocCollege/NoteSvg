package android.graphics;

import android_svg_code_render.AndroidClass;

public class Xfermode extends AndroidClass {
}