package android.graphics;

import android_svg_code_render.AndroidClass;

/**
 * Created by racs on 2015.03.17..
 */
public abstract class PathEffect extends AndroidClass {

    @Override
    protected boolean needsReset() {
        return false;
    }
}
