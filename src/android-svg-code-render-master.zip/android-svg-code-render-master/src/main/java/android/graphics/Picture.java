package android.graphics;

/**
 * Created by racs on 2015.03.17..
 */
public class Picture {
    public Canvas beginRecording(int widthInPixels, int heightInPixels) {
        throw new RuntimeException("Picture.beginRecording() method is not implemented.");
    }

    public void endRecording() {
        throw new RuntimeException("Picture.endRecording() method is not implemented.");
    }
}
