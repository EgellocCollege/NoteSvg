package android.graphics;

import android_svg_code_render.AndroidClass;

public class ColorFilter extends AndroidClass {
}