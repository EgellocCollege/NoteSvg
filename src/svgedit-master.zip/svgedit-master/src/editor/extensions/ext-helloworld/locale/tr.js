export default {
  name: 'Merhaba Dünya',
  text: 'Merhaba Dünya!\n\nBuraya Tıkladınız: {{x}}, {{y}}',
  buttons: [
    {
      title: "'Merhaba Dünya' De"
    }
  ]
}
