export default {
  name: 'Bonjour le Monde',
  text: 'Bonjour le Monde!\n\nVous avez cliqué ici: {{x}}, {{y}}',
  buttons: [
    {
      title: "Dire 'Bonjour le Monde'"
    }
  ]
}
