export default {
  name: 'Привіт Світ',
  text: 'Привіт Світ!\n\nВи клацнули тут: {{x}}, {{y}}',
  buttons: [
    {
      title: "Сказати 'Привіт Світ'"
    }
  ]
}
