export default {
  opensave: {
    new_doc: 'Nouvelle image',
    open_image_doc: 'Ouvrir le SVG',
    save_doc: 'Enregistrer l\'image',
    save_as_doc: 'Enregistrer en tant qu\'image'
  }
}
