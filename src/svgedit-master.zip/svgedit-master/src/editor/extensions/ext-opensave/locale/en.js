export default {
  opensave: {
    new_doc: 'New Image',
    open_image_doc: 'Open SVG',
    save_doc: 'Save SVG',
    save_as_doc: 'Save as SVG'
  }
}
