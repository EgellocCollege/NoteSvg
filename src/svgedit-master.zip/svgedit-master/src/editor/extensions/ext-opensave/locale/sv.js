export default {
  opensave: {
    new_doc: 'Ny bild',
    open_image_doc: 'Öppna SVG',
    save_doc: 'Spara SVG',
    save_as_doc: 'Spara som SVG'
  }
}
