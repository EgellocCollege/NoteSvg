export default {
  opensave: {
    new_doc: 'Yeni Resim',
    open_image_doc: 'SVG Aç',
    save_doc: 'SVG Kaydet',
    save_as_doc: 'SVG olarak Kaydet'
  }
}
