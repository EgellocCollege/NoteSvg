export default {
  opensave: {
    new_doc: 'Нове Зображення',
    open_image_doc: 'Відкрити SVG',
    save_doc: 'Зберегти SVG',
    save_as_doc: 'Зберегти SVG як'
  }
}
