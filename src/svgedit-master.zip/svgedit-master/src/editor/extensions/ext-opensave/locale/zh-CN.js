export default {
  opensave: {
    new_doc: '新图片',
    open_image_doc: '打开 SVG',
    save_doc: '保存图像',
    save_as_doc: '另存为图像'
  }
}
