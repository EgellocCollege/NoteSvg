export default {
  name: 'зірка',
  title: 'Полігон/Зірка',
  buttons: [
    {
      title: 'Зірка'
    },
    {
      title: 'Полігон'
    }
  ],
  contextTools: [
    {
      title: 'Кількість Сторін',
      label: 'точки'
    },
    {
      title: 'Без точок',
      label: 'Без точок'
    },
    {
      title: 'Закручення зірки',
      label: 'Радіальне Зміщення'
    },
    {
      title: 'Кількість Сторін',
      label: 'сторони'
    }
  ]
}
