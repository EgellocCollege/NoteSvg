export default {
  name: 'Розширення: Малювання',
  buttons: [
    {
      title: 'Малювання'
    }
  ]
}
