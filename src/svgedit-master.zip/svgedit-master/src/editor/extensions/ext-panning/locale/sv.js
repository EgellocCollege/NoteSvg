export default {
  name: 'Panorering av tillägg',
  buttons: [
    {
      title: 'Panorering'
    }
  ]
}
