export default {
  name: 'Kaydırma Aracı ',
  buttons: [
    {
      title: 'Kaydırma'
    }
  ]
}
