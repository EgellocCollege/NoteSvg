export default {
  name: '移动',
  buttons: [
    {
      title: '移动'
    }
  ]
}
