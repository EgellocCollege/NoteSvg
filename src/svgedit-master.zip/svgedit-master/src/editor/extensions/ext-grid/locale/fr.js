export default {
  name: 'Grille',
  buttons: [
    {
      title: 'Afficher/Cacher Grille'
    }
  ]
}
