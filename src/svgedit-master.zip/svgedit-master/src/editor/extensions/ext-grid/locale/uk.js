export default {
  name: 'Сітка',
  buttons: [
    {
      title: 'Показати/Заковати Сітку'
    }
  ]
}
