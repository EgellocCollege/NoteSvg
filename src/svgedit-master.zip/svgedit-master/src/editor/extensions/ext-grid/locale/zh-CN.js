export default {
  name: '网格视图',
  buttons: [
    {
      title: '显示/隐藏网格'
    }
  ]
}
