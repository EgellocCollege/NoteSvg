export default {
  name: 'Izgarayı Görüntüle',
  buttons: [
    {
      title: 'Izgara Göster/Gizle'
    }
  ]
}
