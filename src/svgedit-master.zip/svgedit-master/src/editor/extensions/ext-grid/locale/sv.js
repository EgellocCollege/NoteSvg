export default {
  name: 'Visa rutnät',
  buttons: [
    {
      title: 'Visa/dölj rutnät'
    }
  ]
}
