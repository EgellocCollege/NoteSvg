export default {
  name: 'renkseçici',
  buttons: [
    {
      title: 'Renk Seçim Aracı',
      key: 'I'
    }
  ]
}
