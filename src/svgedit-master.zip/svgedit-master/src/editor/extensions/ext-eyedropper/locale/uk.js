export default {
  name: 'eyedropper',
  buttons: [
    {
      title: 'Піпетка',
      key: 'I'
    }
  ]
}
