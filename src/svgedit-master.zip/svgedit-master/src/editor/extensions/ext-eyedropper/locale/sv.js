export default {
  name: 'pipett',
  buttons: [
    {
      title: 'pipettverktyg',
      key: 'I'
    }
  ]
}
