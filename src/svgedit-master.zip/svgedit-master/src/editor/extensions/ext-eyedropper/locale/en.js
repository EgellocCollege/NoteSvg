export default {
  name: 'eyedropper',
  buttons: [
    {
      title: 'Eye Dropper Tool',
      key: 'I'
    }
  ]
}
