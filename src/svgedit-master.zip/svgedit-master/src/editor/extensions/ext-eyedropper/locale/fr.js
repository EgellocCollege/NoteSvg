export default {
  name: 'pipette',
  buttons: [
    {
      title: 'Outil pipette',
      key: 'I'
    }
  ]
}
