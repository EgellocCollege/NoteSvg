export default {
  message: 'Som standard och där det stöds kan SVG-Edit lagra dina redigeringsinställningar ' +
    'och SVG-innehåll lokalt på din maskin så att du inte behöver lägga till dessa igen varje ' +
    'gång du laddar SVG-Edit. Om du av integritetsskäl inte vill lagra denna information på din ' +
    'maskin kan du byta bort från standardalternativet nedan.',
  storagePrefsAndContent: 'Lagra inställningar och SVG-innehåll lokalt',
  storagePrefsOnly: 'Lagra endast inställningar lokalt',
  storagePrefs: 'Lagra inställningar lokalt',
  storageNoPrefsOrContent: 'Lagra inte mina inställningar eller SVG-innehåll lokalt',
  storageNoPrefs: 'Lagra inte mina inställningar lokalt',
  rememberLabel: 'Kommer du ihåg detta val?',
  rememberTooltip: 'Om du väljer att välja bort lagring samtidigt som du kommer ihåg detta val kommer webbadressen att ändras för att undvika att fråga igen.'
}
