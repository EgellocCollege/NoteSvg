import PlainNumberSpinBox from '../src/plain/PlainNumberSpinBox.js'
/**
 * @class ElixNumberSpinBox
 */
export default class ElixNumberSpinBox extends PlainNumberSpinBox {}

customElements.define('elix-number-spin-box', ElixNumberSpinBox)
