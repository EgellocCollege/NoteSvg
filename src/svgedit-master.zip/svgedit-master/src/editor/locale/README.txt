This directory holds JavaScript files that translate the UI strings in SVG-edit.
Initial translations were done by Narendra Sisodiya putting the English
strings through the Google Translation API. Humans will need to take these
automated translations and ensure they make sense.

See AUTHORS for the translations credits.

Languages Already Translated By Humans:
  * lang.cs.js
  * lang.de.js
  * lang.en.js
  * lang.es.js
  * lang.fr.js
  * lang.ja.js
  * lang.nl.js
  * lang.pl.js
  * lang.ro.js
  * lang.sk.js
  * lang.tr.js
