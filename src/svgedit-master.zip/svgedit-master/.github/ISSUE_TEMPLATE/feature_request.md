Please submit Feature Requests in the  [discussion tab](https://github.com/SVG-Edit/svgedit/discussions)
