See also Events
SVG

    Great videos: http://www.adrianparr.com/?p=389
    http://www.w3.org/Graphics/SVG/
    http://en.wikipedia.org/wiki/SVG_Working_Group

JavaScript

    http://www.adrianparr.com/?p=457
    http://www.adrianparr.com/?p=463
    https://www.youtube.com/user/dotconferences

Other

    http://srguiwiz.github.com/adj-js/user-docs/
    http://leosbog.nrvr.com/2013/02/20/writing-svg-to-disk/
    http://www.linkedin.com/groups/Using-SVG-realtime-displays-factory-2549009.S.216775723
    https://code.google.com/p/nanoblok/
    jHotDraw
        http://www.randelshofer.ch/oop/jhotdraw/Documentation/index.html
        http://jhotdraw.org/
    http://svgjs.com/
