The recording is [here](http://tiki.bigbluebutton.org/playback/slides/playback.html?meetingId=c986d4c28a45e0f8bab246354ebfe0422683e9de-1365523345940)

Previous calls: CommunityConferenceCall CommunityConferenceCall2
When

The meeting will be April 9th, 2013 (at 16h00 UTC like the previous one)

Please check for [the time in your time zone](http://www.timeanddate.com/worldclock/fixedtime.html?iso=20130409T1600)
Topics

    Follow-up on Wikipedia progress and the dashboard

Related links

    https://plus.google.com/107010604858430492390/posts/CMUWKL72cw3
    https://twitter.com/SVGedit/status/307888404673216512
    http://www.linkedin.com/groups/SVGedit-3rd-Community-Conference-Call-4712151.S.219028241
    http://www.facebook.com/events/277075235756953/
    https://identi.ca/notice/99881582
