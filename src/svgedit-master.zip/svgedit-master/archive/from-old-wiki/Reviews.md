
    [Short Introduction to SVG-edit](http://ehmdunque.altervista.org/i-informatica/manuali/Short_intro_SVG-edit.html) by Luigi D. CAPRA
    [Ohloh page](http://www.ohloh.net/p/svg-edit)
    [Announcement](https://rusnak.io/svg-edit-a-web-based-svg-editor/) on Pavol's blog
    [How to embed in your web page](http://blog.codedread.com/archives/2009/06/19/embed-an-svg-editor-on-your-web-page/) from Jeff's blog
    [Firefox Add-On](https://addons.mozilla.org/en-US/firefox/addon/14186/) (dead link)
    [gjolesuns's review of Arbelos](http://giizii.com/?p=449)
    [Michael MacNaughton's review of Arbelos](http://www.texaswebdevelopers.com/blog/template_permalink.asp?id=131&utm_source=twitterfeed&utm_medium=twitter)
    [Drawing on your Nokia N900 with SVG-Edit](http://www.jappit.com/blog/2010/02/05/drawing-on-nokia-n900-with-svg-edit/)
    [SitePoint.com review of Arbelos](http://www.sitepoint.com/svg-edit-online-vector-graphics-editor/)
    [Standalone Widget version of Arbelos by Opera](http://my.opera.com/ODIN/blog/2010/02/18/svg-edit-standalone-widget)
    [Another review of SVG-edit 2.4](http://journal.mycom.co.jp/articles/2010/02/24/svgedit/index.html) (Japanese)
    [PC-World article mentioning the SVG-edit Firefox add-on](http://www.pcworld.com/article/190614/svgedit_24.html) (dead link)
    [Download Squad review](http://www.downloadsquad.com/2010/11/15/svg-edit-is-a-surprisingly-powerful-in-browser-vector-image-edit/)
