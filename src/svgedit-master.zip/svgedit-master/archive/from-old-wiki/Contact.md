In general, to contact the SVG-edit community, please see HowToParticipate

For media inquiries or if you need to ask something in private, you can contact marclaporte --at-- gmail --dot-- com
