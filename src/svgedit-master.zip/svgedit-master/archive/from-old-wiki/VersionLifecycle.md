Proposal

The release is by default planned for 12 months after the previous release. However, we can release at any time earlier. For example: * When energy and features are there * Just before a major refactor in trunk
