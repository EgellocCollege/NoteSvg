export default {
  name: 'WebAppFind',
  buttons: [
    {
      title: '保存图片到磁盘'
    }
  ]
};
