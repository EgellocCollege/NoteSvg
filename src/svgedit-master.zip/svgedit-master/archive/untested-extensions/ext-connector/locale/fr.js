export default {
  name: 'Connector',
  langListTitle: 'Connecter deux objets',
  langList: [
    { id: 'mode_connect', title: 'Connecter deux objets' }
  ],
  buttons: [
    {
      title: 'Connecter deux objets'
    }
  ]
};
