export default {
  name: '连接器',
  langListTitle: '连接两个对象',
  langList: [
    { id: 'mode_connect', title: '连接两个对象' }
  ],
  buttons: [
    {
      title: '连接两个对象'
    }
  ]
};
