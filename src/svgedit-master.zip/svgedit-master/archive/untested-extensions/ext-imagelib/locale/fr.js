export default {
  select_lib: "Choisir une bibliothèque d'images",
  show_list: 'show_list',
  import_single: 'import_single',
  import_multi: 'import_multi',
  open: 'open',
  buttons: [
    {
      title: "Bibliothèque d'images"
    }
  ],
  imgLibs_0_name: 'Demo library (local)',
  imgLibs_0_description: 'Demonstration library for SVG-edit on this server',
  imgLibs_1_name: 'IAN Symbol Libraries',
  imgLibs_1_description: 'Free library of illustrations'
}
