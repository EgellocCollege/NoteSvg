export default {
  name: 'ClosePath',
  buttons: [
    {
      title: 'Open path'
    },
    {
      title: 'Close path'
    }
  ]
};
