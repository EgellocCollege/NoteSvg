export default {
  name: '闭合路径',
  buttons: [
    {
      title: '打开路径'
    },
    {
      title: '关闭路径'
    }
  ]
};
