export default {
  uploading: '正在上传...',
  hiddenframe: 'Opensave frame to store hidden values'
};
