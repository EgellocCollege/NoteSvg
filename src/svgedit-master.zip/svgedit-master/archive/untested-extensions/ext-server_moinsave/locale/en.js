export default {
  saved: 'Saved! Return to Item View!',
  hiddenframe: 'Moinsave frame to store hidden values'
};
