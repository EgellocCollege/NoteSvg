export default {
  saved: '已保存! 返回视图!',
  hiddenframe: 'Moinsave frame to store hidden values'
};
