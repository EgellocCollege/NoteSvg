The file below are working with V6 but were not tested with V7
Please open an issue to make them back into the main project.
