package com.github.furutuki.androidsvgtranscoder.sample

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 *
 * @author furutuki
 * created on 2022/12/02
 */
class MainActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.main_activity)
    }
}