var NAVTREE_DATA =
[ [ "com.caverock.androidsvg", "com/caverock/androidsvg/package-summary.html", [ [ "Classes", null, [ [ "PreserveAspectRatio", "com/caverock/androidsvg/PreserveAspectRatio.html", null, "" ], [ "SimpleAssetResolver", "com/caverock/androidsvg/SimpleAssetResolver.html", null, "" ], [ "SVG", "com/caverock/androidsvg/SVG.html", null, "" ], [ "SVGExternalFileResolver", "com/caverock/androidsvg/SVGExternalFileResolver.html", null, "" ], [ "SVGImageView", "com/caverock/androidsvg/SVGImageView.html", null, "" ] ]
, "" ], [ "Enums", null, [ [ "PreserveAspectRatio.Alignment", "com/caverock/androidsvg/PreserveAspectRatio.Alignment.html", null, "" ], [ "PreserveAspectRatio.Scale", "com/caverock/androidsvg/PreserveAspectRatio.Scale.html", null, "" ] ]
, "" ], [ "Exceptions", null, [ [ "SVGParseException", "com/caverock/androidsvg/SVGParseException.html", null, "" ] ]
, "" ] ]
, "" ] ]

;

